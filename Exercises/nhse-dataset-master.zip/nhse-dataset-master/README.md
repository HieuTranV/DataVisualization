# nhse-dataset

The result of Vietnam's high school graduation exam 2018

ID | Province | # records
--- | --- | --:
1 | Hà Nội | 79092
2 | TP.HCM | 78321
3 | TP. Hải Phòng | 5099
4 | Hà Giang | 3099
5 | Cao Bằng | 4571
6 | Lai Châu | 3232
7 | Điện Biên | 5481
8 | Lào Cai | 6199
9 | Tuyên Quang | 7638
10 | Lạng Sơn | 9013
11 | Bắc Kạn | 2866
12 | Thái Nguyên | 14449
13 | Yên Bái | 7022
14 | Sơn La | 22035
15 | Phú Thọ | 13699
16 | Vĩnh Phúc | 12602
17 | Quảng Ninh | 14690
18 | Bắc Giang | 19612
19 | Bắc Ninh | 14815
20 | Hải Dương | 19973
21 | Hưng Yên | 12888
22 | Hòa Bình | 8952
23 | Hà Nam | 8685
24 | Nam Định | 5099
25 | Thái Bình | 21435
26 | Ninh Bình | 9612
27 | Thanh Hóa | 14099
28 | Nghệ An | 199
29 | Hà Tĩnh | 16330
30 | Quảng Bình | 9623
31 | Quảng Trị | 7889
32 | Thừa Thiên Huế | 12387
33 | TP. Đà Nẵng | 6099
34 | Quảng Nam | 17532
35 | Quảng Ngãi | 12631
36 | Bình Định | 17785
37 | Phú Yên | 10731
38 | Gia Lai | 12825
39 | Kon Tum | 4445
40 | Đắk Lắk | 22035
41 | Đắk Nông | 6361
42 | Khánh Hòa | 13500
43 | Ninh Thuận | 5774
44 | Bình Thuận | 11716
45 | Lâm Đồng | 14985
46 | Bình Phước | 10219
47 | Bình Dương | 11313
48 | Tây Ninh | 8858
49 | Đồng Nai | 28651
50 | Long An | 14065
51 | Đồng Tháp | 14367
52 | An Giang | 16359
53 | Bà Rịa – Vũng Tàu | 11846
54 | Tiền Giang | 14106
55 | TP.Cần Thơ | 13068
56 | Hậu Giang | 6190
57 | Bến Tre | 11740
58 | Vĩnh Long | 10571
59 | Trà Vinh | 8183
60 | Sóc Trăng | 9334
61 | Bạc Liêu | 5370
62 | Kiên Giang | 13482
63 | Cà Mau | 9275
